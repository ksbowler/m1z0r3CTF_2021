unzip secret_U.zip
But, do not watch this zip file contents, please.
After unzip, python3 chalU.py
you can connect `nc 127.0.0.1 4000`
