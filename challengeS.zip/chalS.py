#chalS.py

from secretS import p,q,mes
from Crypto.Util.number import *

assert isPrime(p) and isPrime(q)

n = p*q
e = 8750
m = bytes_to_long(mes)
c = pow(m,e,n)
hint = pow((p+q),2,n)

print(f"n = {n}")
print(f"e = {e}")
print(f"c = {c}")
print(f"hint = {hint}")