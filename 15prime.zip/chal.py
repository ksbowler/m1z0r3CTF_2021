from secret import FLAG
from Crypto.Util.number import *

flag = bytes_to_long(FLAG)
f = open("output.txt","w")

while 0 < flag:
    if flag&1:
        r = getPrime(512)
    else:
        r = getPrime(256)*getPrime(256)
    f.write(str(r)+"\n")
    flag >>= 1