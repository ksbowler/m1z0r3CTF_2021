import socketserver  
import socket, os
from Crypto.Util.number import *
from secret import e,n,flag,p,q
import gmpy2


def send_msg(s, msg):  
	enc = msg.encode()  
	s.send(enc)  

def main(s):
	c = pow(bytes_to_long(flag),e,n)
	send_msg(s,"e = "+str(e)+"\n")
	send_msg(s,"n = "+str(n)+"\n")
	send_msg(s,"c = "+str(c)+"\n")
	send_msg(s,"We decrypt an arbitrary ciphertext.\n")
	phi = (p-1)*(q-1)
	d = inverse(e,phi)
	Primes = []
	val = 1
	for _ in range(1024):
		val = int(gmpy2.next_prime(val))
		Primes.append(val)
	Primes = Primes[::-1]

	cnt = 0

	while cnt < 2048:
		cnt += 1
		send_msg(s,"Input ciphertext > ")
		try:
			ct = int(s.recv(4096).decode().strip())
			m = pow(ct,d,n)
			binm = bin(m)[2:]
			binm = "0"*(1024-len(binm))+ binm
			ret = 1
			for i in range(1024):
				if binm[i] == "1": ret *= Primes[i]
				ret %= 1024
			send_msg(s,"Here you are : "+str(ret)+"\n\n")


		except:
			send_msg(s,"Your input is invalid.\n")


class TaskHandler(socketserver.BaseRequestHandler):  
	def handle(self):  
		main(self.request)  

if __name__ == '__main__':  
	socketserver.ThreadingTCPServer.allow_reuse_address = True  
	server = socketserver.ThreadingTCPServer(('127.0.0.1', 5000), TaskHandler)  
	server.serve_forever()
