Don't watch secret.py
python3 server.py
You can connect `nc 127.0.0.1 5000`
