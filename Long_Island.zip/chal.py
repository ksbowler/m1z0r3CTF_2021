from secret import flag
from Crypto.Util.number import *
import random

assert flag[:7] == "m1z0r3{"
assert flag[-1] == "}"

FLAG = bin(bytes_to_long(flag[7:-1].encode()))[2:]

key = bin(random.getrandbits(31))[2:]
assert len(key) == 31

ciphertext = []

for i in range(len(FLAG)):
    ciphertext.append(ord(FLAG[i])^ord(key[i%len(key)]))

print(ciphertext)


